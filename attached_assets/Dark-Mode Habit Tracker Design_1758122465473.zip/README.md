
  # Dark-Mode Habit Tracker Design

  This is a code bundle for Dark-Mode Habit Tracker Design. The original project is available at https://www.figma.com/design/CimhJUCXfPLE032nm6sDtU/Dark-Mode-Habit-Tracker-Design.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  