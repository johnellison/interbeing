import { useState } from "react";
import { ArrowLeft, MapPin, Users, Leaf, Eye } from "lucide-react";
import { CosmicBackground } from "./CosmicBackground";
import { motion } from "motion/react";

interface Project {
  id: string;
  name: string;
  location: string;
  coordinates: { x: number; y: number };
  type: 'reforestation' | 'water' | 'renewable' | 'wildlife' | 'ocean' | 'plastic';
  impact: string;
  description: string;
  beneficiaries: number;
  icon: string;
  color: string;
}

interface ExploreScreenProps {
  onBack: () => void;
}

const projects: Project[] = [
  {
    id: '1',
    name: 'Amazon Reforestation Initiative',
    location: 'Brazil',
    coordinates: { x: 28, y: 60 },
    type: 'reforestation',
    impact: '10,000 trees planted',
    description: 'Restoring degraded rainforest areas and supporting indigenous communities.',
    beneficiaries: 2500,
    icon: '🌳',
    color: 'var(--neon-lime)'
  },
  {
    id: '2',
    name: 'Clean Water Access Project',
    location: 'Kenya',
    coordinates: { x: 60, y: 55 },
    type: 'water',
    impact: '50,000L daily capacity',
    description: 'Building sustainable water infrastructure for rural communities.',
    beneficiaries: 5000,
    icon: '💧',
    color: 'var(--neon-gold)'
  },
  {
    id: '3',
    name: 'Solar Village Initiative',
    location: 'India',
    coordinates: { x: 75, y: 50 },
    type: 'renewable',
    impact: '500kW solar capacity',
    description: 'Bringing clean energy to remote villages through community solar grids.',
    beneficiaries: 8000,
    icon: '☀️',
    color: 'var(--neon-gold)'
  },
  {
    id: '4',
    name: 'Wildlife Corridor Protection',
    location: 'Costa Rica',
    coordinates: { x: 22, y: 52 },
    type: 'wildlife',
    impact: '1,200 hectares protected',
    description: 'Creating safe migration paths for endangered species.',
    beneficiaries: 15000,
    icon: '🦋',
    color: 'var(--cosmic-purple)'
  },
  {
    id: '5',
    name: 'Ocean Plastic Cleanup',
    location: 'Philippines',
    coordinates: { x: 85, y: 55 },
    type: 'ocean',
    impact: '5,000kg plastic removed',
    description: 'Community-led beach cleanups and plastic recycling programs.',
    beneficiaries: 3200,
    icon: '🌊',
    color: 'var(--cosmic-indigo)'
  },
  {
    id: '6',
    name: 'Arctic Research Station',
    location: 'Greenland',
    coordinates: { x: 45, y: 20 },
    type: 'wildlife',
    impact: 'Climate monitoring',
    description: 'Studying ice formation patterns to understand climate change impacts.',
    beneficiaries: 1000000,
    icon: '🔬',
    color: 'var(--star-white)'
  }
];

export function ExploreScreen({ onBack }: ExploreScreenProps) {
  const [selectedProject, setSelectedProject] = useState<Project | null>(null);

  return (
    <div className="relative min-h-screen bg-black">
      <CosmicBackground />
      
      <div className="relative z-10 p-6">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <button 
            onClick={onBack}
            className="w-10 h-10 bg-gray-800/50 backdrop-blur-sm border border-gray-700 rounded-xl flex items-center justify-center hover:border-[var(--neon-lime)]/50 transition-colors"
          >
            <ArrowLeft className="w-5 h-5 text-gray-400" />
          </button>
          <div className="text-center">
            <h1 className="text-xl text-[var(--star-white)]">Explore Impact</h1>
            <p className="text-xs text-gray-400">Global projects you support</p>
          </div>
          <div className="w-10" />
        </div>

        {/* World Map */}
        <div className="bg-gray-900/50 backdrop-blur-sm border border-gray-800 rounded-2xl p-6 mb-6 overflow-hidden">
          <div className="relative w-full h-64">
            {/* Simplified World Map SVG */}
            <svg viewBox="0 0 100 60" className="w-full h-full">
              {/* World continents simplified */}
              <path
                d="M10,25 Q15,20 25,22 L30,25 Q35,23 40,25 L45,30 Q50,28 55,30 L60,25 Q65,23 70,25 L75,22 Q80,20 85,22 L90,25 L88,35 Q85,40 80,38 L75,35 Q70,37 65,35 L60,40 Q55,42 50,40 L45,35 Q40,37 35,35 L30,40 Q25,42 20,40 L15,35 Q12,30 10,25 Z"
                fill="var(--cosmic-indigo)"
                opacity="0.3"
                className="transition-all duration-300"
              />
              
              {/* Project markers */}
              {projects.map((project) => (
                <g key={project.id}>
                  <motion.circle
                    cx={project.coordinates.x}
                    cy={project.coordinates.y}
                    r="2"
                    fill={project.color}
                    className="cursor-pointer"
                    whileHover={{ scale: 1.5 }}
                    whileTap={{ scale: 0.9 }}
                    onClick={() => setSelectedProject(project)}
                  />
                  <motion.circle
                    cx={project.coordinates.x}
                    cy={project.coordinates.y}
                    r="4"
                    fill="none"
                    stroke={project.color}
                    strokeWidth="0.5"
                    opacity="0.6"
                    className="cursor-pointer"
                    animate={{
                      r: [4, 6, 4],
                      opacity: [0.6, 0.2, 0.6]
                    }}
                    transition={{
                      duration: 2,
                      repeat: Infinity,
                      ease: "easeInOut"
                    }}
                    onClick={() => setSelectedProject(project)}
                  />
                </g>
              ))}
            </svg>
          </div>
          
          <div className="mt-4 text-center">
            <p className="text-sm text-gray-400">
              Tap a marker to explore projects around the world
            </p>
          </div>
        </div>

        {/* Selected Project Details */}
        {selectedProject && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-gradient-to-br from-[var(--cosmic-indigo)]/30 to-[var(--cosmic-purple)]/30 backdrop-blur-sm border border-[var(--neon-lime)]/30 rounded-2xl p-6 mb-6"
          >
            <div className="flex items-start space-x-4">
              <div 
                className="w-12 h-12 rounded-xl flex items-center justify-center text-2xl"
                style={{ backgroundColor: `${selectedProject.color}20` }}
              >
                {selectedProject.icon}
              </div>
              
              <div className="flex-1">
                <h3 className="text-[var(--star-white)] mb-1">{selectedProject.name}</h3>
                <div className="flex items-center space-x-2 mb-3">
                  <MapPin className="w-4 h-4 text-gray-400" />
                  <span className="text-sm text-gray-400">{selectedProject.location}</span>
                </div>
                
                <p className="text-sm text-gray-300 mb-4 leading-relaxed">
                  {selectedProject.description}
                </p>
                
                <div className="grid grid-cols-2 gap-4">
                  <div className="bg-gray-800/50 rounded-xl p-3">
                    <div className="flex items-center space-x-2 mb-1">
                      <Leaf className="w-4 h-4" style={{ color: selectedProject.color }} />
                      <span className="text-xs text-gray-400">Impact</span>
                    </div>
                    <p className="text-sm text-[var(--star-white)]">{selectedProject.impact}</p>
                  </div>
                  
                  <div className="bg-gray-800/50 rounded-xl p-3">
                    <div className="flex items-center space-x-2 mb-1">
                      <Users className="w-4 h-4" style={{ color: selectedProject.color }} />
                      <span className="text-xs text-gray-400">Beneficiaries</span>
                    </div>
                    <p className="text-sm text-[var(--star-white)]">
                      {selectedProject.beneficiaries.toLocaleString()}
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </motion.div>
        )}

        {/* Project Grid */}
        <div className="space-y-4">
          <h3 className="text-[var(--star-white)]">All Projects</h3>
          <div className="grid grid-cols-1 gap-3">
            {projects.map((project) => (
              <motion.button
                key={project.id}
                onClick={() => setSelectedProject(project)}
                className={`w-full bg-gray-900/50 backdrop-blur-sm border rounded-2xl p-4 text-left transition-all duration-200 ${
                  selectedProject?.id === project.id
                    ? 'border-[var(--neon-lime)]/50 bg-gray-800/50'
                    : 'border-gray-800 hover:border-gray-700'
                }`}
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    <div 
                      className="w-10 h-10 rounded-xl flex items-center justify-center"
                      style={{ backgroundColor: `${project.color}20` }}
                    >
                      <span className="text-lg">{project.icon}</span>
                    </div>
                    <div>
                      <h4 className="text-[var(--star-white)] text-sm">{project.name}</h4>
                      <p className="text-xs text-gray-400">{project.location}</p>
                    </div>
                  </div>
                  <Eye className="w-5 h-5 text-gray-500" />
                </div>
              </motion.button>
            ))}
          </div>
        </div>

        {/* Impact Summary */}
        <div className="mt-8 bg-gray-900/50 backdrop-blur-sm border border-gray-800 rounded-2xl p-6">
          <h3 className="text-[var(--star-white)] mb-4 text-center">Your Collective Impact</h3>
          <div className="grid grid-cols-2 gap-4">
            <div className="text-center">
              <div className="text-2xl text-[var(--neon-lime)] mb-1">127K</div>
              <div className="text-xs text-gray-400">Lives Touched</div>
            </div>
            <div className="text-center">
              <div className="text-2xl text-[var(--neon-gold)] mb-1">6</div>
              <div className="text-xs text-gray-400">Countries</div>
            </div>
          </div>
          <p className="text-center text-sm text-gray-300 mt-4">
            Through mindful daily habits, our community creates ripples of positive change across the planet.
          </p>
        </div>
      </div>
    </div>
  );
}