export function CosmicBackground() {
  return (
    <div className="fixed inset-0 overflow-hidden pointer-events-none">
      {/* Gradient background */}
      <div className="absolute inset-0 bg-gradient-to-br from-[var(--deep-space)] via-[var(--cosmic-indigo)] to-black opacity-60" />
      
      {/* Floating stars */}
      <div className="absolute inset-0">
        {Array.from({ length: 20 }).map((_, i) => (
          <div
            key={i}
            className="absolute w-1 h-1 bg-[var(--star-white)] rounded-full opacity-60 animate-pulse"
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
              animationDelay: `${Math.random() * 3}s`,
              animationDuration: `${2 + Math.random() * 2}s`
            }}
          />
        ))}
      </div>
      
      {/* Cosmic orbs */}
      <div className="absolute top-20 right-10 w-32 h-32 bg-[var(--cosmic-purple)] rounded-full opacity-10 blur-xl" />
      <div className="absolute bottom-32 left-8 w-24 h-24 bg-[var(--neon-lime)] rounded-full opacity-10 blur-lg" />
      <div className="absolute top-1/2 left-1/3 w-16 h-16 bg-[var(--neon-gold)] rounded-full opacity-15 blur-md" />
    </div>
  );
}