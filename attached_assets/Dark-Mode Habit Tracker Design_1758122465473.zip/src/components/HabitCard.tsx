import { CheckCircle, Circle } from "lucide-react";

export interface Habit {
  id: string;
  name: string;
  icon: string;
  completed: boolean;
  streak: number;
  impact: string;
}

interface HabitCardProps {
  habit: Habit;
  onToggle: (id: string) => void;
  onClick: (habit: Habit) => void;
}

export function HabitCard({ habit, onToggle, onClick }: HabitCardProps) {
  return (
    <div 
      className="bg-gray-900/50 backdrop-blur-sm border border-gray-800 rounded-2xl p-4 cursor-pointer hover:bg-gray-800/50 transition-all duration-200 hover:border-[var(--neon-lime)]/30"
      onClick={() => onClick(habit)}
    >
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-4">
          {/* Habit Icon */}
          <div className="w-12 h-12 bg-gradient-to-br from-[var(--cosmic-indigo)] to-[var(--cosmic-purple)] rounded-xl flex items-center justify-center">
            <span className="text-xl">{habit.icon}</span>
          </div>
          
          {/* Habit Info */}
          <div>
            <h3 className="text-[var(--star-white)] mb-1">{habit.name}</h3>
            <p className="text-xs text-gray-400">{habit.streak} day streak</p>
          </div>
        </div>
        
        {/* Completion Toggle */}
        <button
          onClick={(e) => {
            e.stopPropagation();
            onToggle(habit.id);
          }}
          className="p-1"
        >
          {habit.completed ? (
            <CheckCircle className="w-6 h-6 text-[var(--neon-lime)]" />
          ) : (
            <Circle className="w-6 h-6 text-gray-600 hover:text-[var(--neon-lime)] transition-colors" />
          )}
        </button>
      </div>
      
      {/* Impact preview */}
      <div className="mt-3 pt-3 border-t border-gray-800">
        <p className="text-xs text-[var(--neon-gold)]">🌱 {habit.impact}</p>
      </div>
    </div>
  );
}