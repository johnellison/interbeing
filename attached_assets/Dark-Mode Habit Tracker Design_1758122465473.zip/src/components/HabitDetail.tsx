import { ArrowLeft, CheckCircle, Flame } from "lucide-react";
import { Button } from "./ui/button";
import { CosmicBackground } from "./CosmicBackground";
import { Habit } from "./HabitCard";

interface HabitDetailProps {
  habit: Habit;
  onBack: () => void;
  onComplete: () => void;
  onCelebration: () => void;
}

export function HabitDetail({ habit, onBack, onComplete, onCelebration }: HabitDetailProps) {
  const handleComplete = () => {
    onComplete();
    if (!habit.completed) {
      onCelebration();
    }
  };

  return (
    <div className="relative min-h-screen bg-black">
      <CosmicBackground />
      
      <div className="relative z-10 p-6">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <button 
            onClick={onBack}
            className="w-10 h-10 bg-gray-800/50 backdrop-blur-sm border border-gray-700 rounded-xl flex items-center justify-center hover:border-[var(--neon-lime)]/50 transition-colors"
          >
            <ArrowLeft className="w-5 h-5 text-gray-400" />
          </button>
        </div>
        
        {/* Habit Icon & Name */}
        <div className="text-center mb-12">
          <div className="w-24 h-24 mx-auto mb-6 bg-gradient-to-br from-[var(--cosmic-indigo)] to-[var(--cosmic-purple)] rounded-3xl flex items-center justify-center">
            <span className="text-4xl">{habit.icon}</span>
          </div>
          <h1 className="text-3xl text-[var(--star-white)] mb-2">{habit.name}</h1>
          <p className="text-base text-gray-400">Building a better tomorrow</p>
        </div>
        
        {/* Streak Counter */}
        <div className="bg-gray-900/50 backdrop-blur-sm border border-gray-800 rounded-2xl p-6 mb-8">
          <div className="flex items-center justify-center space-x-3 mb-4">
            <Flame className="w-6 h-6 text-[var(--neon-gold)]" />
            <span className="text-2xl text-[var(--star-white)]">{habit.streak}</span>
            <span className="text-base text-gray-400">day streak</span>
          </div>
          <div className="text-center">
            <p className="text-sm text-gray-500">
              {habit.streak > 0 ? "Keep the momentum going!" : "Start your journey today"}
            </p>
          </div>
        </div>
        
        {/* Environmental Impact */}
        <div className="bg-gradient-to-br from-[var(--cosmic-indigo)]/20 to-[var(--cosmic-purple)]/20 backdrop-blur-sm border border-[var(--cosmic-indigo)]/30 rounded-2xl p-6 mb-12">
          <h3 className="text-[var(--star-white)] mb-3">Environmental Impact</h3>
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-[var(--neon-lime)]/20 rounded-xl flex items-center justify-center">
              <span className="text-lg">🌱</span>
            </div>
            <div>
              <p className="text-[var(--neon-gold)]">{habit.impact}</p>
              <p className="text-xs text-gray-400 mt-1">
                Your daily action contributes to global change
              </p>
            </div>
          </div>
        </div>
        
        {/* Complete Button */}
        <div className="space-y-4">
          <Button
            onClick={handleComplete}
            disabled={habit.completed}
            className={`w-full h-14 transition-all duration-300 ${
              habit.completed
                ? 'bg-gray-800 text-gray-400 cursor-not-allowed'
                : 'bg-gradient-to-r from-[var(--neon-lime)] to-[var(--neon-gold)] hover:from-[var(--neon-gold)] hover:to-[var(--neon-lime)] text-black shadow-lg shadow-[var(--neon-lime)]/20'
            }`}
          >
            {habit.completed ? (
              <div className="flex items-center space-x-2">
                <CheckCircle className="w-5 h-5" />
                <span>Completed Today</span>
              </div>
            ) : (
              'Complete Habit'
            )}
          </Button>
          
          {habit.completed && (
            <p className="text-center text-sm text-[var(--neon-lime)]">
              Great job! Come back tomorrow to continue your streak.
            </p>
          )}
        </div>
      </div>
    </div>
  );
}