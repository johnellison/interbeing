import { useState } from "react";
import { ArrowLeft, Calendar, Trophy, Zap, Filter } from "lucide-react";
import { CosmicBackground } from "./CosmicBackground";
import { motion } from "motion/react";

interface TimelineEvent {
  id: string;
  date: string;
  type: 'habit_completed' | 'streak_milestone' | 'impact_achieved' | 'habit_created';
  habitName: string;
  habitIcon: string;
  description: string;
  impact?: string;
  streakCount?: number;
  timestamp: Date;
}

interface TimelineScreenProps {
  onBack: () => void;
}

// Mock timeline data - in a real app this would come from a database
const generateTimelineEvents = (): TimelineEvent[] => {
  const events: TimelineEvent[] = [];
  const habits = [
    { name: 'Morning Meditation', icon: '🧘‍♀️', impact: 'Plant 1 Tree' },
    { name: 'Mindful Eating', icon: '🥗', impact: 'Save 50L of Water' },
    { name: 'Digital Detox', icon: '📱', impact: 'Reduce 2kg CO2' },
    { name: 'Gratitude Journal', icon: '📝', impact: 'Remove 1kg Plastic' },
    { name: 'Walking in Nature', icon: '🌲', impact: 'Support Local Wildlife' }
  ];

  // Generate events for the last 30 days
  for (let i = 0; i < 30; i++) {
    const date = new Date();
    date.setDate(date.getDate() - i);
    
    // Random habit completions
    const randomHabits = habits.sort(() => 0.5 - Math.random()).slice(0, Math.floor(Math.random() * 3) + 1);
    
    randomHabits.forEach((habit, index) => {
      events.push({
        id: `${i}-${index}`,
        date: date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' }),
        type: 'habit_completed',
        habitName: habit.name,
        habitIcon: habit.icon,
        description: 'Completed daily practice',
        impact: habit.impact,
        timestamp: new Date(date.getTime() + index * 1000)
      });
    });

    // Random milestones
    if (Math.random() > 0.8) {
      const randomHabit = habits[Math.floor(Math.random() * habits.length)];
      const streakCount = [7, 14, 21, 30][Math.floor(Math.random() * 4)];
      
      events.push({
        id: `milestone-${i}`,
        date: date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' }),
        type: 'streak_milestone',
        habitName: randomHabit.name,
        habitIcon: randomHabit.icon,
        description: `Reached ${streakCount}-day streak!`,
        streakCount,
        timestamp: new Date(date.getTime() + 5000)
      });
    }
  }

  return events.sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime());
};

export function TimelineScreen({ onBack }: TimelineScreenProps) {
  const [timelineEvents] = useState<TimelineEvent[]>(generateTimelineEvents());
  const [filter, setFilter] = useState<'all' | 'completions' | 'milestones'>('all');

  const filteredEvents = timelineEvents.filter(event => {
    if (filter === 'completions') return event.type === 'habit_completed';
    if (filter === 'milestones') return event.type === 'streak_milestone';
    return true;
  });

  const groupedEvents = filteredEvents.reduce((groups, event) => {
    const date = event.date;
    if (!groups[date]) groups[date] = [];
    groups[date].push(event);
    return groups;
  }, {} as Record<string, TimelineEvent[]>);

  const getEventIcon = (event: TimelineEvent) => {
    switch (event.type) {
      case 'streak_milestone':
        return <Trophy className="w-4 h-4 text-[var(--neon-gold)]" />;
      case 'impact_achieved':
        return <Zap className="w-4 h-4 text-[var(--neon-lime)]" />;
      default:
        return <span className="text-sm">{event.habitIcon}</span>;
    }
  };

  const getEventColor = (event: TimelineEvent) => {
    switch (event.type) {
      case 'streak_milestone':
        return 'var(--neon-gold)';
      case 'impact_achieved':
        return 'var(--neon-lime)';
      default:
        return 'var(--cosmic-indigo)';
    }
  };

  return (
    <div className="relative min-h-screen bg-black">
      <CosmicBackground />
      
      <div className="relative z-10 p-6">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <button 
            onClick={onBack}
            className="w-10 h-10 bg-gray-800/50 backdrop-blur-sm border border-gray-700 rounded-xl flex items-center justify-center hover:border-[var(--neon-lime)]/50 transition-colors"
          >
            <ArrowLeft className="w-5 h-5 text-gray-400" />
          </button>
          <div className="text-center">
            <h1 className="text-xl text-[var(--star-white)]">Timeline</h1>
            <p className="text-xs text-gray-400">Your journey of impact</p>
          </div>
          <div className="w-10" />
        </div>

        {/* Filter Pills */}
        <div className="flex space-x-2 mb-6 overflow-x-auto">
          {[
            { key: 'all', label: 'All Events', icon: Calendar },
            { key: 'completions', label: 'Completions', icon: Zap },
            { key: 'milestones', label: 'Milestones', icon: Trophy }
          ].map(({ key, label, icon: Icon }) => (
            <button
              key={key}
              onClick={() => setFilter(key as any)}
              className={`flex items-center space-x-2 px-4 py-2 rounded-full whitespace-nowrap transition-all duration-200 ${
                filter === key
                  ? 'bg-gradient-to-r from-[var(--neon-lime)] to-[var(--neon-gold)] text-black'
                  : 'bg-gray-800/50 border border-gray-700 text-gray-300 hover:border-gray-600'
              }`}
            >
              <Icon className="w-4 h-4" />
              <span className="text-sm">{label}</span>
            </button>
          ))}
        </div>

        {/* Timeline Stats */}
        <div className="bg-gray-900/50 backdrop-blur-sm border border-gray-800 rounded-2xl p-6 mb-6">
          <div className="grid grid-cols-3 gap-4">
            <div className="text-center">
              <div className="text-2xl text-[var(--neon-lime)] mb-1">
                {timelineEvents.filter(e => e.type === 'habit_completed').length}
              </div>
              <div className="text-xs text-gray-400">Completions</div>
            </div>
            <div className="text-center">
              <div className="text-2xl text-[var(--neon-gold)] mb-1">
                {timelineEvents.filter(e => e.type === 'streak_milestone').length}
              </div>
              <div className="text-xs text-gray-400">Milestones</div>
            </div>
            <div className="text-center">
              <div className="text-2xl text-[var(--cosmic-purple)] mb-1">30</div>
              <div className="text-xs text-gray-400">Days Active</div>
            </div>
          </div>
        </div>

        {/* Timeline */}
        <div className="space-y-6">
          {Object.entries(groupedEvents).map(([date, events]) => (
            <div key={date} className="relative">
              {/* Date Header */}
              <div className="flex items-center space-x-3 mb-4">
                <div className="bg-gray-800/50 backdrop-blur-sm border border-gray-700 rounded-lg px-3 py-1">
                  <span className="text-sm text-[var(--star-white)]">{date}</span>
                </div>
                <div className="flex-1 h-px bg-gray-700/50" />
              </div>

              {/* Events for this date */}
              <div className="space-y-3 pl-4">
                {events.map((event, index) => (
                  <motion.div
                    key={event.id}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: index * 0.1 }}
                    className="relative"
                  >
                    {/* Timeline connector */}
                    <div 
                      className="absolute left-0 top-0 w-px h-full bg-gradient-to-b from-transparent via-gray-600 to-transparent"
                    />
                    
                    {/* Event marker */}
                    <div 
                      className="absolute left-0 top-6 w-2 h-2 rounded-full transform -translate-x-1/2"
                      style={{ backgroundColor: getEventColor(event) }}
                    />

                    {/* Event content */}
                    <div className="ml-6 bg-gray-900/50 backdrop-blur-sm border border-gray-800 rounded-2xl p-4">
                      <div className="flex items-start space-x-3">
                        <div 
                          className="w-10 h-10 rounded-xl flex items-center justify-center"
                          style={{ backgroundColor: `${getEventColor(event)}20` }}
                        >
                          {getEventIcon(event)}
                        </div>
                        
                        <div className="flex-1">
                          <div className="flex items-center space-x-2 mb-1">
                            <h4 className="text-[var(--star-white)] text-sm">{event.habitName}</h4>
                            {event.type === 'streak_milestone' && (
                              <div className="bg-[var(--neon-gold)]/20 px-2 py-1 rounded-full">
                                <span className="text-xs text-[var(--neon-gold)]">
                                  {event.streakCount} days
                                </span>
                              </div>
                            )}
                          </div>
                          
                          <p className="text-xs text-gray-400 mb-2">{event.description}</p>
                          
                          {event.impact && (
                            <div className="flex items-center space-x-2">
                              <div className="w-1 h-1 rounded-full bg-[var(--neon-lime)]" />
                              <span className="text-xs text-[var(--neon-lime)]">{event.impact}</span>
                            </div>
                          )}
                        </div>
                      </div>
                    </div>
                  </motion.div>
                ))}
              </div>
            </div>
          ))}
        </div>

        {/* Journey Summary */}
        <div className="mt-8 bg-gradient-to-br from-[var(--cosmic-indigo)]/30 to-[var(--cosmic-purple)]/30 backdrop-blur-sm border border-[var(--neon-lime)]/30 rounded-2xl p-6">
          <div className="text-center">
            <h3 className="text-[var(--star-white)] mb-2">Your Impact Journey</h3>
            <p className="text-sm text-gray-300 mb-4">
              Every small action creates ripples of positive change across the cosmos.
            </p>
            <div className="flex justify-center space-x-6">
              <div className="text-center">
                <div className="text-lg text-[var(--neon-lime)]">🌱</div>
                <div className="text-xs text-gray-400">Growing</div>
              </div>
              <div className="text-center">
                <div className="text-lg text-[var(--neon-gold)]">✨</div>
                <div className="text-xs text-gray-400">Connecting</div>
              </div>
              <div className="text-center">
                <div className="text-lg text-[var(--cosmic-purple)]">🌍</div>
                <div className="text-xs text-gray-400">Transforming</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}