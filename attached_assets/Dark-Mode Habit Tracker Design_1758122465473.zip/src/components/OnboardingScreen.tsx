import { Button } from "./ui/button";
import { CosmicBackground } from "./CosmicBackground";

interface OnboardingScreenProps {
  onGetStarted: () => void;
}

export function OnboardingScreen({ onGetStarted }: OnboardingScreenProps) {
  return (
    <div className="relative min-h-screen bg-black flex flex-col items-center justify-center px-6 text-center">
      <CosmicBackground />
      
      <div className="relative z-10 max-w-sm mx-auto space-y-8">
        {/* Logo */}
        <div className="mb-12">
          <div className="w-20 h-20 mx-auto mb-6 bg-gradient-to-br from-[var(--neon-lime)] to-[var(--neon-gold)] rounded-2xl flex items-center justify-center">
            <div className="w-12 h-12 bg-black rounded-xl flex items-center justify-center">
              <div className="w-6 h-6 bg-[var(--neon-lime)] rounded-full opacity-80" />
            </div>
          </div>
          <h1 className="text-3xl font-medium text-[var(--star-white)] mb-2">Interbeing</h1>
          <p className="text-sm text-gray-400">Connect your habits to the world</p>
        </div>
        
        {/* Welcome text */}
        <div className="space-y-4">
          <h2 className="text-xl text-[var(--star-white)]">
            Every small action creates ripples across the cosmos
          </h2>
          <p className="text-base text-gray-300 leading-relaxed">
            Track your daily habits and watch how your personal growth connects to environmental impact, one mindful step at a time.
          </p>
        </div>
        
        {/* CTA Button */}
        <Button 
          onClick={onGetStarted}
          className="w-full h-14 bg-gradient-to-r from-[var(--neon-lime)] to-[var(--neon-gold)] hover:from-[var(--neon-gold)] hover:to-[var(--neon-lime)] text-black transition-all duration-300 shadow-lg shadow-[var(--neon-lime)]/20"
        >
          Get Started
        </Button>
        
        <p className="text-xs text-gray-500 mt-4">
          Join the movement of conscious living
        </p>
      </div>
    </div>
  );
}