import { useState } from "react";
import { ArrowLeft, Check } from "lucide-react";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { CosmicBackground } from "./CosmicBackground";
import { Habit } from "./HabitCard";

interface AddHabitScreenProps {
  onBack: () => void;
  onSave: (habit: Omit<Habit, 'id' | 'completed' | 'streak'>) => void;
}

const habitIcons = [
  '🧘‍♀️', '🥗', '📱', '📝', '🌲', '💧', '🚶‍♀️', '📚', '🎨', '🎵',
  '☀️', '🌙', '🏃‍♀️', '🧘‍♂️', '🍃', '🌱', '🔋', '♻️', '🌍', '✨'
];

const impactOptions = [
  'Plant 1 Tree',
  'Save 50L of Water', 
  'Reduce 2kg CO2',
  'Remove 1kg Plastic',
  'Support Local Wildlife',
  'Restore 1m² of Ocean',
  'Save 100Wh Energy',
  'Fund Clean Water Access',
  'Protect Rainforest',
  'Support Solar Power'
];

export function AddHabitScreen({ onBack, onSave }: AddHabitScreenProps) {
  const [step, setStep] = useState(1);
  const [habitName, setHabitName] = useState('');
  const [selectedIcon, setSelectedIcon] = useState('');
  const [selectedImpact, setSelectedImpact] = useState('');

  const handleSave = () => {
    if (habitName && selectedIcon && selectedImpact) {
      onSave({
        name: habitName,
        icon: selectedIcon,
        impact: selectedImpact
      });
    }
  };

  const canProceedStep1 = habitName.trim().length > 0;
  const canProceedStep2 = selectedIcon.length > 0;
  const canSave = selectedImpact.length > 0;

  return (
    <div className="relative min-h-screen bg-black">
      <CosmicBackground />
      
      <div className="relative z-10 p-6">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <button 
            onClick={step === 1 ? onBack : () => setStep(step - 1)}
            className="w-10 h-10 bg-gray-800/50 backdrop-blur-sm border border-gray-700 rounded-xl flex items-center justify-center hover:border-[var(--neon-lime)]/50 transition-colors"
          >
            <ArrowLeft className="w-5 h-5 text-gray-400" />
          </button>
          
          <div className="text-center">
            <h1 className="text-xl text-[var(--star-white)]">Add Habit</h1>
            <p className="text-xs text-gray-400">Step {step} of 3</p>
          </div>
          
          <div className="w-10" />
        </div>

        {/* Progress Steps */}
        <div className="flex justify-center mb-12">
          <div className="flex space-x-2">
            {[1, 2, 3].map((stepNumber) => (
              <div
                key={stepNumber}
                className={`w-2 h-2 rounded-full transition-all duration-300 ${
                  stepNumber <= step 
                    ? 'bg-[var(--neon-lime)]' 
                    : 'bg-gray-700'
                }`}
              />
            ))}
          </div>
        </div>

        {/* Step 1: Habit Name */}
        {step === 1 && (
          <div className="space-y-8">
            <div className="text-center mb-8">
              <h2 className="text-2xl text-[var(--star-white)] mb-3">
                Name Your Habit
              </h2>
              <p className="text-base text-gray-300">
                What positive practice would you like to cultivate?
              </p>
            </div>

            <div className="space-y-6">
              <div className="bg-gray-900/50 backdrop-blur-sm border border-gray-800 rounded-2xl p-6">
                <Input
                  value={habitName}
                  onChange={(e) => setHabitName(e.target.value)}
                  placeholder="e.g., Morning gratitude practice"
                  className="bg-transparent border-none text-[var(--star-white)] placeholder:text-gray-500 text-lg text-center p-0 focus-visible:ring-0"
                  autoFocus
                />
              </div>

              <div className="space-y-3">
                <p className="text-sm text-gray-400 text-center">Suggested habits:</p>
                <div className="flex flex-wrap gap-2 justify-center">
                  {['Daily meditation', 'Plant-based meal', 'Digital sunset', 'Nature walk'].map((suggestion) => (
                    <button
                      key={suggestion}
                      onClick={() => setHabitName(suggestion)}
                      className="px-4 py-2 bg-gray-800/50 border border-gray-700 rounded-full text-sm text-gray-300 hover:border-[var(--neon-lime)]/50 hover:text-[var(--star-white)] transition-colors"
                    >
                      {suggestion}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            <Button
              onClick={() => setStep(2)}
              disabled={!canProceedStep1}
              className={`w-full h-14 transition-all duration-300 ${
                canProceedStep1
                  ? 'bg-gradient-to-r from-[var(--neon-lime)] to-[var(--neon-gold)] hover:from-[var(--neon-gold)] hover:to-[var(--neon-lime)] text-black shadow-lg shadow-[var(--neon-lime)]/20'
                  : 'bg-gray-800 text-gray-500 cursor-not-allowed'
              }`}
            >
              Choose Icon
            </Button>
          </div>
        )}

        {/* Step 2: Icon Selection */}
        {step === 2 && (
          <div className="space-y-8">
            <div className="text-center mb-8">
              <h2 className="text-2xl text-[var(--star-white)] mb-3">
                Choose an Icon
              </h2>
              <p className="text-base text-gray-300">
                Pick a symbol that represents your habit
              </p>
            </div>

            <div className="bg-gray-900/50 backdrop-blur-sm border border-gray-800 rounded-2xl p-6">
              <div className="grid grid-cols-5 gap-4">
                {habitIcons.map((icon) => (
                  <button
                    key={icon}
                    onClick={() => setSelectedIcon(icon)}
                    className={`w-12 h-12 rounded-xl flex items-center justify-center text-2xl transition-all duration-200 ${
                      selectedIcon === icon
                        ? 'bg-gradient-to-br from-[var(--neon-lime)] to-[var(--neon-gold)] shadow-lg shadow-[var(--neon-lime)]/30'
                        : 'bg-gray-800/50 hover:bg-gray-700/50'
                    }`}
                  >
                    {icon}
                  </button>
                ))}
              </div>
            </div>

            {selectedIcon && (
              <div className="text-center">
                <div className="w-16 h-16 mx-auto bg-gradient-to-br from-[var(--cosmic-indigo)] to-[var(--cosmic-purple)] rounded-2xl flex items-center justify-center mb-3">
                  <span className="text-3xl">{selectedIcon}</span>
                </div>
                <p className="text-sm text-[var(--neon-gold)]">Perfect choice!</p>
              </div>
            )}

            <Button
              onClick={() => setStep(3)}
              disabled={!canProceedStep2}
              className={`w-full h-14 transition-all duration-300 ${
                canProceedStep2
                  ? 'bg-gradient-to-r from-[var(--neon-lime)] to-[var(--neon-gold)] hover:from-[var(--neon-gold)] hover:to-[var(--neon-lime)] text-black shadow-lg shadow-[var(--neon-lime)]/20'
                  : 'bg-gray-800 text-gray-500 cursor-not-allowed'
              }`}
            >
              Choose Impact
            </Button>
          </div>
        )}

        {/* Step 3: Environmental Impact */}
        {step === 3 && (
          <div className="space-y-8">
            <div className="text-center mb-8">
              <h2 className="text-2xl text-[var(--star-white)] mb-3">
                Environmental Impact
              </h2>
              <p className="text-base text-gray-300">
                Connect your habit to planetary healing
              </p>
            </div>

            <div className="space-y-3">
              {impactOptions.map((impact) => (
                <button
                  key={impact}
                  onClick={() => setSelectedImpact(impact)}
                  className={`w-full p-4 rounded-2xl text-left transition-all duration-200 ${
                    selectedImpact === impact
                      ? 'bg-gradient-to-br from-[var(--cosmic-indigo)]/30 to-[var(--cosmic-purple)]/30 border border-[var(--neon-lime)]/50'
                      : 'bg-gray-900/50 border border-gray-800 hover:border-gray-700'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-3">
                      <div className="w-8 h-8 bg-[var(--neon-lime)]/20 rounded-lg flex items-center justify-center">
                        <span className="text-sm">🌱</span>
                      </div>
                      <span className="text-[var(--star-white)]">{impact}</span>
                    </div>
                    {selectedImpact === impact && (
                      <Check className="w-5 h-5 text-[var(--neon-lime)]" />
                    )}
                  </div>
                </button>
              ))}
            </div>

            <div className="space-y-4">
              <Button
                onClick={handleSave}
                disabled={!canSave}
                className={`w-full h-14 transition-all duration-300 ${
                  canSave
                    ? 'bg-gradient-to-r from-[var(--neon-lime)] to-[var(--neon-gold)] hover:from-[var(--neon-gold)] hover:to-[var(--neon-lime)] text-black shadow-lg shadow-[var(--neon-lime)]/20'
                    : 'bg-gray-800 text-gray-500 cursor-not-allowed'
                }`}
              >
                Create Habit
              </Button>

              {selectedImpact && (
                <div className="text-center">
                  <p className="text-sm text-[var(--neon-gold)]">
                    🌍 Your daily practice will help: {selectedImpact.toLowerCase()}
                  </p>
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}