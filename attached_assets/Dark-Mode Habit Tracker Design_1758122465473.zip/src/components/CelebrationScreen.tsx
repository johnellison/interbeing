import { Button } from "./ui/button";
import { CosmicBackground } from "./CosmicBackground";
import { motion } from "motion/react";

interface CelebrationScreenProps {
  impact: string;
  onContinue: () => void;
}

export function CelebrationScreen({ impact, onContinue }: CelebrationScreenProps) {
  return (
    <div className="relative min-h-screen bg-black flex flex-col items-center justify-center px-6">
      <CosmicBackground />
      
      <div className="relative z-10 text-center max-w-sm mx-auto">
        {/* Animated Icon */}
        <motion.div
          initial={{ scale: 0, rotate: -180 }}
          animate={{ scale: 1, rotate: 0 }}
          transition={{ duration: 0.8, ease: "easeOut" }}
          className="mb-8"
        >
          <div className="w-32 h-32 mx-auto bg-gradient-to-br from-[var(--neon-lime)] to-[var(--neon-gold)] rounded-full flex items-center justify-center shadow-lg shadow-[var(--neon-lime)]/30">
            <span className="text-6xl">🌱</span>
          </div>
        </motion.div>
        
        {/* Celebration Text */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3, duration: 0.6 }}
          className="space-y-4 mb-8"
        >
          <h1 className="text-3xl text-[var(--star-white)]">Amazing!</h1>
          <p className="text-base text-gray-300 leading-relaxed">
            Your mindful action just created a ripple of positive change across the cosmos.
          </p>
        </motion.div>
        
        {/* Impact Achievement */}
        <motion.div
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.6, duration: 0.5 }}
          className="bg-gradient-to-br from-[var(--cosmic-indigo)]/30 to-[var(--cosmic-purple)]/30 backdrop-blur-sm border border-[var(--neon-lime)]/30 rounded-2xl p-6 mb-8"
        >
          <h3 className="text-[var(--neon-gold)] mb-2">Impact Achieved</h3>
          <p className="text-[var(--star-white)]">{impact}</p>
        </motion.div>
        
        {/* Floating particles */}
        <div className="absolute inset-0 pointer-events-none">
          {Array.from({ length: 12 }).map((_, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, scale: 0, y: 0 }}
              animate={{ 
                opacity: [0, 1, 0],
                scale: [0, 1, 0],
                y: -100
              }}
              transition={{
                delay: 0.8 + i * 0.1,
                duration: 2,
                ease: "easeOut"
              }}
              className="absolute w-2 h-2 bg-[var(--neon-lime)] rounded-full"
              style={{
                left: `${20 + Math.random() * 60}%`,
                top: "50%"
              }}
            />
          ))}
        </div>
        
        {/* Continue Button */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 1.2, duration: 0.5 }}
        >
          <Button
            onClick={onContinue}
            className="w-full h-14 bg-gradient-to-r from-[var(--neon-lime)] to-[var(--neon-gold)] hover:from-[var(--neon-gold)] hover:to-[var(--neon-lime)] text-black transition-all duration-300 shadow-lg shadow-[var(--neon-lime)]/20"
          >
            Continue Journey
          </Button>
        </motion.div>
      </div>
    </div>
  );
}