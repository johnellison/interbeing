import { Plus, BarChart3, User, Globe, Clock } from "lucide-react";
import { HabitCard, Habit } from "./HabitCard";
import { CosmicBackground } from "./CosmicBackground";

interface HabitDashboardProps {
  habits: Habit[];
  onToggleHabit: (id: string) => void;
  onHabitClick: (habit: Habit) => void;
  onStatsClick: () => void;
  onAddHabit: () => void;
  onExploreClick: () => void;
  onTimelineClick: () => void;
}

export function HabitDashboard({ habits, onToggleHabit, onHabitClick, onStatsClick, onAddHabit, onExploreClick, onTimelineClick }: HabitDashboardProps) {
  const completedToday = habits.filter(h => h.completed).length;
  const totalHabits = habits.length;
  
  return (
    <div className="relative min-h-screen bg-black">
      <CosmicBackground />
      
      <div className="relative z-10 p-6 pb-20">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-2xl text-[var(--star-white)] mb-1">Today</h1>
            <p className="text-sm text-gray-400">
              {completedToday} of {totalHabits} habits completed
            </p>
          </div>
          <div className="flex space-x-2">
            <button 
              onClick={onExploreClick}
              className="w-10 h-10 bg-gray-800/50 backdrop-blur-sm border border-gray-700 rounded-xl flex items-center justify-center hover:border-[var(--neon-lime)]/50 transition-colors"
            >
              <Globe className="w-5 h-5 text-gray-400" />
            </button>
            <button 
              onClick={onStatsClick}
              className="w-10 h-10 bg-gray-800/50 backdrop-blur-sm border border-gray-700 rounded-xl flex items-center justify-center hover:border-[var(--neon-lime)]/50 transition-colors"
            >
              <BarChart3 className="w-5 h-5 text-gray-400" />
            </button>
            <button 
              onClick={onTimelineClick}
              className="w-10 h-10 bg-gray-800/50 backdrop-blur-sm border border-gray-700 rounded-xl flex items-center justify-center hover:border-[var(--neon-lime)]/50 transition-colors"
            >
              <Clock className="w-5 h-5 text-gray-400" />
            </button>
          </div>
        </div>
        
        {/* Progress Ring */}
        <div className="flex justify-center mb-8">
          <div className="relative w-24 h-24">
            <svg className="w-24 h-24 transform -rotate-90" viewBox="0 0 100 100">
              <circle
                cx="50"
                cy="50"
                r="40"
                stroke="currentColor"
                strokeWidth="8"
                fill="none"
                className="text-gray-800"
              />
              <circle
                cx="50"
                cy="50"
                r="40"
                stroke="url(#gradient)"
                strokeWidth="8"
                fill="none"
                strokeDasharray={`${(completedToday / totalHabits) * 251.2} 251.2`}
                className="transition-all duration-500"
              />
              <defs>
                <linearGradient id="gradient" x1="0%" y1="0%" x2="100%" y2="0%">
                  <stop offset="0%" stopColor="var(--neon-lime)" />
                  <stop offset="100%" stopColor="var(--neon-gold)" />
                </linearGradient>
              </defs>
            </svg>
            <div className="absolute inset-0 flex items-center justify-center">
              <span className="text-lg text-[var(--star-white)]">
                {Math.round((completedToday / totalHabits) * 100)}%
              </span>
            </div>
          </div>
        </div>
        
        {/* Habits List */}
        <div className="space-y-4">
          {habits.map((habit) => (
            <HabitCard
              key={habit.id}
              habit={habit}
              onToggle={onToggleHabit}
              onClick={onHabitClick}
            />
          ))}
        </div>
        
        {/* Add Habit Button */}
        <button 
          onClick={onAddHabit}
          className="fixed bottom-6 right-6 w-14 h-14 bg-gradient-to-r from-[var(--neon-lime)] to-[var(--neon-gold)] rounded-full flex items-center justify-center shadow-lg shadow-[var(--neon-lime)]/20 hover:scale-105 transition-transform"
        >
          <Plus className="w-6 h-6 text-black" />
        </button>
      </div>
    </div>
  );
}