import { ArrowLeft, Leaf, Droplets, Recycle } from "lucide-react";
import { CosmicBackground } from "./CosmicBackground";
import { LineChart, Line, XAxis, YAxis, ResponsiveContainer } from "recharts";

interface StatsScreenProps {
  onBack: () => void;
}

const mockData = [
  { day: 'Mon', completed: 2 },
  { day: 'Tue', completed: 3 },
  { day: 'Wed', completed: 4 },
  { day: 'Thu', completed: 3 },
  { day: 'Fri', completed: 5 },
  { day: 'Sat', completed: 4 },
  { day: 'Sun', completed: 6 },
];

const impactStats = [
  { icon: <Leaf className="w-5 h-5" />, label: "Trees Planted", value: "23", color: "var(--neon-lime)" },
  { icon: <Droplets className="w-5 h-5" />, label: "Water Saved", value: "145L", color: "var(--neon-gold)" },
  { icon: <Recycle className="w-5 h-5" />, label: "Plastic Removed", value: "8kg", color: "var(--cosmic-purple)" },
];

export function StatsScreen({ onBack }: StatsScreenProps) {
  return (
    <div className="relative min-h-screen bg-black">
      <CosmicBackground />
      
      <div className="relative z-10 p-6">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <button 
            onClick={onBack}
            className="w-10 h-10 bg-gray-800/50 backdrop-blur-sm border border-gray-700 rounded-xl flex items-center justify-center hover:border-[var(--neon-lime)]/50 transition-colors"
          >
            <ArrowLeft className="w-5 h-5 text-gray-400" />
          </button>
          <h1 className="text-xl text-[var(--star-white)]">Your Impact</h1>
          <div className="w-10" />
        </div>
        
        {/* Weekly Progress Chart */}
        <div className="bg-gray-900/50 backdrop-blur-sm border border-gray-800 rounded-2xl p-6 mb-6">
          <h3 className="text-[var(--star-white)] mb-4">This Week</h3>
          <div className="h-40">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={mockData}>
                <XAxis 
                  dataKey="day" 
                  axisLine={false}
                  tickLine={false}
                  tick={{ fill: '#9CA3AF', fontSize: 12 }}
                />
                <YAxis hide />
                <Line 
                  type="monotone" 
                  dataKey="completed" 
                  stroke="var(--neon-lime)"
                  strokeWidth={3}
                  dot={{ fill: 'var(--neon-lime)', strokeWidth: 0, r: 4 }}
                  activeDot={{ r: 6, fill: 'var(--neon-gold)' }}
                />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>
        
        {/* Impact Statistics */}
        <div className="space-y-4 mb-6">
          <h3 className="text-[var(--star-white)]">Environmental Impact</h3>
          {impactStats.map((stat, index) => (
            <div 
              key={index}
              className="bg-gray-900/50 backdrop-blur-sm border border-gray-800 rounded-2xl p-4"
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <div 
                    className="w-10 h-10 rounded-xl flex items-center justify-center"
                    style={{ backgroundColor: `${stat.color}20` }}
                  >
                    <div style={{ color: stat.color }}>
                      {stat.icon}
                    </div>
                  </div>
                  <span className="text-[var(--star-white)]">{stat.label}</span>
                </div>
                <span 
                  className="text-xl"
                  style={{ color: stat.color }}
                >
                  {stat.value}
                </span>
              </div>
            </div>
          ))}
        </div>
        
        {/* Total Impact Summary */}
        <div className="bg-gradient-to-br from-[var(--cosmic-indigo)]/30 to-[var(--cosmic-purple)]/30 backdrop-blur-sm border border-[var(--neon-lime)]/30 rounded-2xl p-6">
          <div className="text-center">
            <h3 className="text-[var(--star-white)] mb-2">Cosmic Ripple Effect</h3>
            <p className="text-sm text-gray-300 mb-4">
              Your 27 completed habits this month have created positive change across the interconnected web of life.
            </p>
            <div className="flex justify-center space-x-6">
              <div className="text-center">
                <div className="text-2xl text-[var(--neon-lime)]">89%</div>
                <div className="text-xs text-gray-400">Consistency</div>
              </div>
              <div className="text-center">
                <div className="text-2xl text-[var(--neon-gold)]">15</div>
                <div className="text-xs text-gray-400">Day Streak</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}