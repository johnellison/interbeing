import { useState } from "react";
import { OnboardingScreen } from "./components/OnboardingScreen";
import { HabitDashboard } from "./components/HabitDashboard";
import { HabitDetail } from "./components/HabitDetail";
import { CelebrationScreen } from "./components/CelebrationScreen";
import { StatsScreen } from "./components/StatsScreen";
import { AddHabitScreen } from "./components/AddHabitScreen";
import { ExploreScreen } from "./components/ExploreScreen";
import { TimelineScreen } from "./components/TimelineScreen";
import { Habit } from "./components/HabitCard";

type Screen = 'onboarding' | 'dashboard' | 'detail' | 'celebration' | 'stats' | 'addHabit' | 'explore' | 'timeline';

const mockHabits: Habit[] = [
  {
    id: '1',
    name: 'Morning Meditation',
    icon: '🧘‍♀️',
    completed: false,
    streak: 7,
    impact: 'Plant 1 Tree'
  },
  {
    id: '2',
    name: 'Mindful Eating',
    icon: '🥗',
    completed: true,
    streak: 12,
    impact: 'Save 50L of Water'
  },
  {
    id: '3',
    name: 'Digital Detox',
    icon: '📱',
    completed: false,
    streak: 3,
    impact: 'Reduce 2kg CO2'
  },
  {
    id: '4',
    name: 'Gratitude Journal',
    icon: '📝',
    completed: true,
    streak: 21,
    impact: 'Remove 1kg Plastic'
  },
  {
    id: '5',
    name: 'Walking in Nature',
    icon: '🌲',
    completed: false,
    streak: 5,
    impact: 'Support Local Wildlife'
  }
];

export default function App() {
  const [currentScreen, setCurrentScreen] = useState<Screen>('onboarding');
  const [selectedHabit, setSelectedHabit] = useState<Habit | null>(null);
  const [habits, setHabits] = useState<Habit[]>(mockHabits);

  const handleToggleHabit = (id: string) => {
    setHabits(habits.map(habit => 
      habit.id === id 
        ? { 
            ...habit, 
            completed: !habit.completed,
            streak: !habit.completed ? habit.streak + 1 : habit.streak
          }
        : habit
    ));
  };

  const handleHabitClick = (habit: Habit) => {
    setSelectedHabit(habit);
    setCurrentScreen('detail');
  };

  const handleCompleteHabit = () => {
    if (selectedHabit) {
      handleToggleHabit(selectedHabit.id);
      setSelectedHabit({
        ...selectedHabit,
        completed: true,
        streak: selectedHabit.streak + 1
      });
    }
  };

  const handleAddHabit = (newHabitData: Omit<Habit, 'id' | 'completed' | 'streak'>) => {
    const newHabit: Habit = {
      ...newHabitData,
      id: Date.now().toString(),
      completed: false,
      streak: 0
    };
    setHabits([...habits, newHabit]);
    setCurrentScreen('dashboard');
  }; 

  return (
    <div className="size-full min-h-screen bg-black dark">
      {currentScreen === 'onboarding' && (
        <OnboardingScreen onGetStarted={() => setCurrentScreen('dashboard')} />
      )}
      
      {currentScreen === 'dashboard' && (
        <HabitDashboard
          habits={habits}
          onToggleHabit={handleToggleHabit}
          onHabitClick={handleHabitClick}
          onStatsClick={() => setCurrentScreen('stats')}
          onAddHabit={() => setCurrentScreen('addHabit')}
          onExploreClick={() => setCurrentScreen('explore')}
          onTimelineClick={() => setCurrentScreen('timeline')}
        />
      )}
      
      {currentScreen === 'detail' && selectedHabit && (
        <HabitDetail
          habit={habits.find(h => h.id === selectedHabit.id) || selectedHabit}
          onBack={() => setCurrentScreen('dashboard')}
          onComplete={handleCompleteHabit}
          onCelebration={() => setCurrentScreen('celebration')}
        />
      )}
      
      {currentScreen === 'celebration' && selectedHabit && (
        <CelebrationScreen
          impact={selectedHabit.impact}
          onContinue={() => setCurrentScreen('dashboard')}
        />
      )}
      
      {currentScreen === 'stats' && (
        <StatsScreen onBack={() => setCurrentScreen('dashboard')} />
      )}
      
      {currentScreen === 'addHabit' && (
        <AddHabitScreen 
          onBack={() => setCurrentScreen('dashboard')}
          onSave={handleAddHabit} 
        />
      )}
      
      {currentScreen === 'explore' && (
        <ExploreScreen onBack={() => setCurrentScreen('dashboard')} />
      )}
      
      {currentScreen === 'timeline' && (
        <TimelineScreen onBack={() => setCurrentScreen('dashboard')} />
      )}
    </div>
  );
}